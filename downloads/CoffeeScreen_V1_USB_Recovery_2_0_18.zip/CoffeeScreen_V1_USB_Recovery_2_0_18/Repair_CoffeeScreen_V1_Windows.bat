@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
title CoffeeScreen FOX - V1 Recovery 2.0.18

echo.
echo  CoffeeScreen FOX - استعادة شاشة ون
echo  هذا الملف مخصص لوحدات ون فقط.
echo  لا تفصل الكيبل اثناء التثبيت.
echo.

where py >nul 2>nul
if errorlevel 1 goto no_python

py -m esptool version >nul 2>nul
if errorlevel 1 (
  echo تجهيز اداة التثبيت للمرة الاولى...
  py -m pip install --user esptool
  if errorlevel 1 goto install_failed
)

echo.
echo افتح إدارة الأجهزة ثم ابحث عن المنفذ الظاهر بجانب USB Serial، مثال: COM3
set /p PORT=اكتب المنفذ: 
if "%PORT%"=="" goto no_port

set /p CONFIRM=اكتب REPAIR للبدء: 
if /I not "%CONFIRM%"=="REPAIR" (
  echo أُلغي؛ لم يتغير شيء.
  pause
  exit /b 0
)

py -m esptool --chip esp32 --port %PORT% --baud 460800 write-flash -z 0xe000 firmware\boot_app0.bin 0x10000 firmware\CoffeeScreen-V1-2.0.18.bin
if errorlevel 1 goto failed

echo.
echo تم الإصلاح. انتظر 20 ثانية، ثم افتح الشاشة وجرب ربط الاكسبلوم ووصفة واحدة.
pause
exit /b 0

:no_python
echo لم أجد Python. ثبّت Python 3 من Microsoft Store ثم أعد تشغيل هذا الملف.
pause
exit /b 1

:install_failed
echo تعذر تجهيز الأداة. تأكد من اتصال الإنترنت ثم أعد المحاولة.
pause
exit /b 1

:no_port
echo لم تدخل منفذًا. أُلغي.
pause
exit /b 1

:failed
echo لم يكتمل الإصلاح. تأكد من منفذ COM والكيبل، ثم افصل الشاشة وأعد وصلها.
pause
exit /b 1
